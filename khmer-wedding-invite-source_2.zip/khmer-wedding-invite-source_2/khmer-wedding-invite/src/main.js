import './styles.css';
import { W } from './data/wedding.js';
import { I } from './i18n.js';
import sprite from './sprite.js';
import heroLg from './assets/couple-1280.webp';
import heroSm from './assets/couple-640.webp';
import musicUrl from './assets/music.mp3';
import { mount, navHtml } from './sections.js';

const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const store = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch {} } };
const QA = location.search.includes('qa');
const reduce = matchMedia('(prefers-reduced-motion:reduce)').matches;
const weak = (navigator.hardwareConcurrency || 8) <= 4 || (navigator.deviceMemory || 8) <= 2;
let lang = store.get('lang') || 'km';

/* scalloped flap outline in objectBoundingBox units (also drives the gold line) */
function scallop(n = 9, aspect = .41, bulge = .05) {
  const edge = (a, b) => { let d = ''; for (let i = 0; i < n; i++) {
    const x0 = a[0] + (b[0] - a[0]) * i / n, y0 = a[1] + (b[1] - a[1]) * i / n, x1 = a[0] + (b[0] - a[0]) * (i + 1) / n, y1 = a[1] + (b[1] - a[1]) * (i + 1) / n;
    const dx = x1 - x0, dy = (y1 - y0) * aspect, len = Math.hypot(dx, dy);
    d += `Q${(x0 + x1) / 2 - dy / len * bulge} ${(y0 + y1) / 2 + dx / len * bulge / aspect} ${x1} ${y1}`; } return d; };
  return `M0 0${edge([0, 0], [.5, 1])}${edge([.5, 1], [1, 0])}Z`;
}
const FLAP = scallop();

const logo = (cls = '') => `<div class="logo ${cls}"><svg class="logo-crest foil-svg"><use href="#el-crest"/></svg>
<div class="names"><span class="n n1 foil" data-n="groom"></span>
<svg class="flourish" viewBox="0 0 100 40" preserveAspectRatio="none"><path pathLength="1" d="M2 38C26 38 30 6 52 20S82 6 98 2"/></svg>
<svg class="heart"><use href="#heart"/></svg><svg class="bfly"><use href="#el-butterfly"/></svg>
<span class="n n2 foil" data-n="bride"></span></div></div>`;
const corner = (c, m) => `<svg class="corner ${c}" viewBox="0 0 160 160"><g transform="${m}"><use href="#el-corner"/></g></svg>`;
const cell = (i, l, v) => `<div style="--i:${i}"><small class="kh" data-t="${l}"></small><b data-t="${v}"></b></div>`;

$('#app').innerHTML = `${sprite}
<svg width="0" height="0" style="position:absolute" aria-hidden="true"><clipPath id="flapClip" clipPathUnits="objectBoundingBox"><path d="${FLAP}"/></clipPath></svg>
<header class="bar">${logo('mini')}<div class="tools">
 <button class="ic" id="lang" aria-label="Language"></button>
 <button class="ic" id="snd" aria-label="Music"><svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path class="on" d="M16.5 8.500a5 5 0 0 1 0 7M19 6a8.500 8.500 0 0 1 0 12"/></svg></button></div></header>
<main>
<section class="cover" id="cover">
 <div class="cover-bg"><img class="blur" src="${heroSm}" alt=""><img class="main" src="${heroLg}" alt=""></div><div class="cover-shade"></div>
 ${corner('tl', '')}${corner('tr', 'matrix(-1 0 0 1 160 0)')}${corner('bl', 'matrix(1 0 0 -1 0 160)')}${corner('br', 'matrix(-1 0 0 -1 160 160)')}
 <div class="cover-in">
  <div class="c1"><svg class="crest r"><use href="#el-crest"/></svg>
  <p class="kicker kh foil unveil" data-t="kicker"></p>
  ${logo('cover-logo')}
  <p class="en-names rise" style="--i:0" data-t="names"></p></div>
  <div class="c2"><p class="invite kh rise" style="--i:1" data-t="invite"></p>
  <div class="date kh">${cell(0, 'lDay', 'vDay')}${cell(1, 'lDate', 'vDate')}${cell(2, 'lMon', 'vMon')}${cell(3, 'lYear', 'vYear')}</div>
  <p class="venue kh rise" style="--i:3" data-t="venue"></p>
  <div class="cue rise" style="--i:4"><span data-t="scroll"></span><i></i></div></div>
 </div>
</section>
<div id="sx"></div>
</main>
${navHtml}
<section class="gate" id="gate">
 <div class="gate-bg"><img src="${heroSm}" alt=""></div>
 <div class="gate-title"><p class="a kh" data-t="gateA"></p><p class="b">The Wedding Invitation</p></div>
 <div class="scene" id="scene"><div class="tilt" id="tilt"><div class="stage" id="stage">
  <div class="env" id="env">
   <div class="back"></div>
   <div class="pocket"><i class="pl"></i><i class="pr"></i><i class="pb"></i></div>
   <div class="fsh" id="fsh"><i></i></div>
   <div class="flap" id="flap"><div class="ff">${logo()}<svg class="fline" viewBox="0 0 1 1" preserveAspectRatio="none"><path d="${FLAP}" transform="translate(.035 .02) scale(.93 .9)"/></svg></div><div class="fb"></div></div>
  </div>
  <div class="card" id="card"><svg class="crest"><use href="#el-crest"/></svg><p class="t kh foil" data-t="gateA"></p>${logo()}<p class="d kh" data-t="vDay"></p></div>
  <button class="seal" id="seal" aria-label="Open the invitation"><svg viewBox="0 0 140 140"><use href="#el-wax-seal"/></svg></button>
 </div></div></div>
 <button class="tap kh" id="tap" data-t="tap"></button>
 <div class="fade" id="fade"></div>
</section>`;

/* text + language */
const renderSx = mount({ logo });
function paint() {
  renderSx(lang);
  const L = I[lang]; document.documentElement.lang = lang === 'km' ? 'km' : 'en';
  $$('[data-t]').forEach(e => e.textContent = L[e.dataset.t]);
  $$('[data-n]').forEach(e => e.textContent = W[e.dataset.n][lang === 'km' ? 'shortKm' : 'shortEn']);
  $$('.n').forEach(e => e.classList.toggle('kh', lang === 'km'));
  $('#lang').textContent = L.other; store.set('lang', lang);
}
paint();
$('#lang').onclick = () => { lang = lang === 'km' ? 'en' : 'km'; paint(); fit(); };
/* safety net: if the cover content is taller than the screen, scale it down so it always fits one screen */
const cin = $('.cover-in'), cov = $('#cover');
function fit() { cin.style.transform = ''; const cs = getComputedStyle(cov), avail = cov.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) + 24, k = Math.min(1, avail / cin.offsetHeight); cin.style.transform = k < 1 ? `scale(${k.toFixed(3)})` : ''; }
addEventListener('resize', fit); document.fonts?.ready.then(fit); fit();

/* music */
const audio = new Audio(musicUrl); audio.loop = true; audio.volume = 0; let on = false;
const sndUi = () => $('#snd .on').style.opacity = on ? 1 : 0;
function play() { audio.play().then(() => { on = true; sndUi(); let v = 0; const f = setInterval(() => { audio.volume = Math.min(.7, v += .035); if (v >= .7) clearInterval(f); }, 120); }).catch(() => {}); }
$('#snd').onclick = () => { if (on) { audio.pause(); on = false; } else { audio.play(); audio.volume = .7; on = true; } sndUi(); };
sndUi();

/* idle float + tilt */
const stage = $('#stage'), tilt = $('#tilt');
const idle = reduce ? null : stage.animate([{ transform: 'translateY(0) rotateZ(-.5deg)' }, { transform: 'translateY(-7px) rotateZ(.5deg)' }], { duration: 4200, direction: 'alternate', iterations: Infinity, easing: 'ease-in-out' });
const setTilt = (rx, ry) => { tilt.style.setProperty('--rx', rx + 'deg'); tilt.style.setProperty('--ry', ry + 'deg'); };
const gate = $('#gate');
gate.addEventListener('pointermove', e => setTilt(-((e.clientY / innerHeight) - .5) * 8, ((e.clientX / innerWidth) - .5) * 10));
addEventListener('deviceorientation', e => { if (gate.isConnected && e.gamma != null) setTilt(Math.max(-6, Math.min(6, ((e.beta || 50) - 50) / -8)), Math.max(-8, Math.min(8, e.gamma / 6))); });

/* opening sequence (~5.5 s) */
let started = false; const A = [];
function open() {
  if (started) return; started = true; play();
  idle?.cancel(); tilt.style.transition = 'none'; setTilt(0, 0);
  $('#tap').style.visibility = 'hidden';
  if (reduce) { $('#fade').animate({ opacity: [0, 1] }, { duration: 400, fill: 'forwards' }); return void setTimeout(reveal, 450); }
  const go = (el, kf, at, dur, ease = 'cubic-bezier(.45,0,.2,1)', fill = 'both') => { const a = el.animate(kf, { delay: at, duration: dur, easing: ease, fill }); A.push(a); return a; };
  const Z = 'translateZ(14px)', shadow = s => `drop-shadow(${s})`;
  /* seal: pressed -> lifted (shadow grows) -> set aside off screen */
  go($('.seal svg'), [{ filter: shadow('0 3px 3px rgba(0,0,0,.5)') }, { filter: shadow('0 3px 3px rgba(0,0,0,.5)'), offset: .22 }, { filter: shadow('0 22px 16px rgba(0,0,0,.42)'), offset: .6 }, { filter: shadow('0 30px 20px rgba(0,0,0,.3)') }], 0, 2050, 'linear');
  go($('#seal'), [
    { transform: `${Z} scale(1)`, easing: 'ease-in-out' }, { transform: `${Z} scale(.92)`, offset: .22, easing: 'cubic-bezier(.3,0,.2,1)' },
    { transform: `translateZ(60px) translateY(-9%) scale(1.22)`, offset: .6, easing: 'cubic-bezier(.5,0,.3,1)' },
    { transform: `translate3d(${innerWidth * .8}px,${-innerHeight * .1}px,80px) rotate(40deg) scale(.9)` }], 0, 2050, 'linear');
  /* flap folds back 180deg; once past 90deg it drops behind the card */
  go($('#flap'), [{ transform: 'translateZ(8px) rotateX(0deg)', easing: 'cubic-bezier(.5,0,.8,.6)' }, { transform: 'translateZ(8px) rotateX(90deg)', offset: .5 },
    { transform: 'translateZ(1px) rotateX(90deg)', offset: .5, easing: 'cubic-bezier(.2,.5,.3,1)' }, { transform: 'translateZ(1px) rotateX(180deg)' }], 1800, 1500, 'linear');
  go($('#fsh'), [{ opacity: 1 }, { opacity: 0 }], 1800, 800);
  /* card drawn out, envelope sinks, then drops away while the card comes to camera */
  go($('#card'), [{ transform: 'translateZ(3px)' }, { transform: 'translateZ(3px) translateY(-44%) rotate(-1.8deg)' }], 3150, 1250, 'cubic-bezier(.3,.1,.2,1)');
  const r = $('#card').getBoundingClientRect(), s = Math.min(innerWidth * 1.08 / r.width, innerHeight * .9 / r.height * 1.6);
  go($('#card'), [{ transform: 'translateZ(3px) translateY(-44%) rotate(-1.8deg)' },
    { transform: `translate3d(${innerWidth / 2 - r.left - r.width / 2}px,${innerHeight / 2 - r.top - r.height / 2}px,90px) scale(${s}) rotate(0deg)` }], 4400, 900, 'cubic-bezier(.5,0,.2,1)', 'forwards');
  go($('#env'), [{ transform: 'translateY(0)' }, { transform: 'translateY(7%)' }], 3150, 1250, 'ease-in-out');
  go($('#env'), [{ transform: 'translateY(7%)' }, { transform: `translateY(${innerHeight}px)` }], 4400, 900, 'cubic-bezier(.6,0,.9,.4)', 'forwards');
  go($('#fade'), [{ opacity: 0 }, { opacity: 1 }], 4950, 550, 'ease-in', 'forwards');
  if (!QA) setTimeout(reveal, 5550);
}
function reveal() {
  document.body.classList.add('opened'); $$('.logo').forEach(l => l.classList.add('play'));
  gate.animate({ opacity: [1, 0] }, { duration: 800, fill: 'forwards', easing: 'ease-out' }).onfinish = () => gate.remove();
}
$('#seal').onclick = $('#tap').onclick = open;
addEventListener('scroll', () => document.body.classList.toggle('scrolled', scrollY > 30), { passive: true });
if (weak) document.documentElement.classList.add('lite');
window.__qa = { seek: t => A.forEach(a => { a.pause(); a.currentTime = t; }), reveal, open };
