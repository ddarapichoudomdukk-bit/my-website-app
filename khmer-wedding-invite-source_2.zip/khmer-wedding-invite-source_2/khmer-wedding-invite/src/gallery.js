import s0 from './assets/g/121a1406-640.webp';import l0 from './assets/g/121a1406-1280.webp';
import s1 from './assets/g/121a1902-640.webp';import l1 from './assets/g/121a1902-1280.webp';
import s2 from './assets/g/121a1179-640.webp';import l2 from './assets/g/121a1179-1280.webp';
import s3 from './assets/g/121a2193-640.webp';import l3 from './assets/g/121a2193-1280.webp';
import s4 from './assets/g/121a1541-640.webp';import l4 from './assets/g/121a1541-1280.webp';
import s5 from './assets/g/121a1299-640.webp';import l5 from './assets/g/121a1299-1280.webp';
import s6 from './assets/g/121a1636-640.webp';import l6 from './assets/g/121a1636-1280.webp';
import s7 from './assets/g/121a1629-640.webp';import l7 from './assets/g/121a1629-1280.webp';
export default [{id:'121a1406',w:1365,h:2048,sm:s0,lg:l0},{id:'121a1902',w:1365,h:2048,sm:s1,lg:l1},{id:'121a1179',w:1365,h:2048,sm:s2,lg:l2},{id:'121a2193',w:3072,h:2048,sm:s3,lg:l3},{id:'121a1541',w:1365,h:2048,sm:s4,lg:l4},{id:'121a1299',w:1365,h:2048,sm:s5,lg:l5},{id:'121a1636',w:1365,h:2048,sm:s6,lg:l6},{id:'121a1629',w:1365,h:2048,sm:s7,lg:l7}];