// All wedding facts live here. null = still needed from the couple (nothing is invented).
export const W = {
  groom: {
    km: "ភាព សំរេច",
    en: "Pheap Samrach",
    shortKm: "សំរេច",
    shortEn: "Samrach",
  },
  bride: {
    km: "ឌុក ដារ៉ារស្មី",
    en: "Duk Darareaksmey",
    shortKm: "ដារ៉ារស្មី",
    shortEn: "Darareaksmey",
  },
  date: {
    y: 2026,
    m: 11,
    d: 21,
    weekdayKm: "សៅរ៏",
    weekdayEn: "Satursday",
    monthKm: "វិច្ឆិកា",
    monthEn: "November",
  },
  lunar: null, // e.g. 'ត្រូវនឹងថ្ងៃ…'  — not provided
  venue: {
    km: "Battambang Cityhall (អគារ A) ភូមិចំការសំរោង សង្កាត់ចំការសំរោង ក្រុងបាត់ដំបង ខេត្តបាត់ដំបង",
    en: "Battambang Cityhall (Building A), Chamkar Samraong, Battambang",
    maps: "https://maps.app.goo.gl/Za71nTHcoArD3bTb8",
    lat: null,
    lng: null,
    query: "Battambang Cityhall, Battambang", // needed for the embedded map
  },
  countdown: "2026-11-21T17:00:00+07:00", // from the couple's page: Sat 21 Nov, 5:00 PM (Cambodia time)
  // Programme read from the couple's own page recording. km:null = name not legible yet (row stays hidden).
  // VERIFY minutes on 13:50, 15:45, 07:15, 10:15 and the two hidden rows.
  programme: [
    {
      km: "ថ្ងៃសុក្រ ទី២០ ខែវិច្ឆិកា ឆ្នាំ២០២៦",
      en: "Friday, 20 November 2026",
      items: [
        { t: "13:10", km: "ពិធីក្រុងពាលី", en: "Kroung Pali ceremony" },
        { t: "13:50", km: "ពិធីកាត់សក់", en: "Hair-cutting ceremony" },
        { t: "15:45", km: "ពិធីសូត្រមន្ត", en: "Chanting ceremony" },
        {
          t: "18:10",
          km: "ពិធីជាវខាន់ស្លា + បុកល័ក្ខ",
          en: "Khan Sla Ceremony and Bok Leak Ceremony",
        },
      ],
    },
    {
      km: "ថ្ងៃសៅរ៍ ទី២១ ខែវិច្ឆិកា ឆ្នាំ២០២៦",
      en: "Saturday, 21 November 2026",
      items: [
        {
          t: "07:15",
          km: "ពីធីជំនូនជូនស្លា (កំណត់)",
          en: "Wedding Gift Procession",
        },
        { t: "10:15", km: "ពិធីសែនចងដៃ", en: "Hand-binding ceremony" },
        {
          t: "17:00",
          km: "ពិធីអញ្ជើញភ្ញៀវកិត្តិយសពិសាភោជនាហារ",
          en: "Honoured guests dinner reception",
        },
      ],
    },
  ],
  wishesEndpoint: "", // where guest wishes are POSTed (Telegram bot / Google Sheet / Formspree) — not chosen yet
  groomParents: null,
  brideParents: null,
  siteUrl: "", // filled at deploy: used for og:image
};
