import { W } from './data/wedding.js';
import { I, kn } from './i18n.js';
import G from './gallery.js';
import qr from './assets/qr-aba.jpg';

const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const n = (v, l) => l === 'km' ? kn(v) : String(v);
const tm = (t, l) => { const [h, m] = t.split(':').map(Number), h12 = h % 12 || 12, mm = String(m).padStart(2, '0');
  return l === 'km' ? `${kn(h12)}:${kn(mm)} ${h < 12 ? 'ព្រឹក' : 'ល្ងាច'}` : `${h12}:${mm} ${h < 12 ? 'AM' : 'PM'}`; };
const P = d => `<svg viewBox="0 0 24 24" class="gi"><path d="${d}"/></svg>`;
const IC = { home: 'M4 11l8-7 8 7v9h-5v-6H9v6H4z', cal: 'M5 5h14v15H5zM5 9h14M9 3v4M15 3v4', pin: 'M12 21s-6-5.5-6-10a6 6 0 0 1 12 0c0 4.5-6 10-6 10zM12 8.5a2 2 0 1 0 0 4 2 2 0 0 0 0-4',
  img: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4', gift: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2v2h-2zM18 14h2v6h-4M14 18h2v2h-2z', chat: 'M4 5h16v11H9l-5 4z',
  tg: 'M21 4L3 11l6 2 2 6 3-4 5 4zM9 13l12-9', fb: 'M14 8h3V4h-3a4 4 0 0 0-4 4v3H7v4h3v6h4v-6h3l1-4h-4V8z', ms: 'M12 3a9 9 0 0 0-9 9c0 3 1.5 5 3.5 6.5V22l3.2-1.800A9 9 0 1 0 12 3zM7 14l4-4 2 2 4-4', cp: 'M10 14a4 4 0 0 0 6 0l3-3a4 4 0 0 0-6-6l-1 1M14 10a4 4 0 0 0-6 0l-3 3a4 4 0 0 0 6 6l1-1' };
const SEC = [['home', '#cover'], ['cal', '#countdown'], ['pin', '#venue'], ['img', '#gallery'], ['gift', '#gift'], ['chat', '#wishes']];
export const navHtml = `<nav class="nav" aria-label="Sections">${SEC.map(([k, h]) => `<button data-go="${h}" data-k="${k}" aria-label="${k}">${P(IC[k])}</button>`).join('')}</nav><button class="totop" data-go="#cover" aria-label="Top">${P('M6 15l6-6 6 6M6 20l6-6 6 6')}</button>`;

let LOGO = () => '', lang = 'km';
const html = l => { const L = I[l], orn = '<svg class="orn"><use href="#el-divider"/></svg>';
  const days = W.programme.map(d => `<div class="day" data-in><h3 class="kh">${d[l]}</h3><div class="prog"><i class="thread"><b></b></i>${d.items.filter(i => i.km && i.en).map(i => `<div class="row"><time class="foil kh">${tm(i.t, l)}</time><p class="kh">${i[l]}</p></div>`).join('')}</div></div>`).join('');
  const map = `https://maps.google.com/maps?q=${W.venue.lat ? W.venue.lat + ',' + W.venue.lng : encodeURIComponent(W.venue.query)}&output=embed`;
  return `<section id="countdown"><h2 class="sec-h kh foil sheen">${L.cdH}</h2><p class="kh sub">${L.cdLine}</p>
  <div class="tiles" data-in>${L.cd.map((x, i) => `<div class="tile t-flip" style="--i:${i}"><b data-cd="${'dhms'[i]}">0</b><small class="kh">${x}</small></div>`).join('')}</div>
  <div class="btns"><button class="btn kh" data-ics>${L.cal}</button></div></section>
  <section id="programme"><h2 class="sec-h kh foil">${L.progH}</h2>${orn}${days}</section>
  <section id="venue"><h2 class="sec-h kh foil">${L.venueH}</h2>${orn}<p class="kh sub">${L.venue}</p>
  <iframe class="map" title="Map" loading="lazy" src="${map}"></iframe><div class="btns"><a class="btn kh" href="${W.venue.maps}" target="_blank" rel="noopener">${L.mapBtn}</a></div></section>
  <section id="gallery"><h2 class="sec-h kh foil">${L.galH}</h2>${orn}<div class="masonry">${G.map((g, i) => `<figure class="t-clip" data-in data-g="${i}" style="aspect-ratio:${g.w}/${g.h}"><img loading="lazy" decoding="async" src="${g.sm}" alt=""></figure>`).join('')}</div></section>
  <section id="thanks"><h2 class="sec-h kh foil">${L.thxH}</h2>${orn}<p class="kh body">${L.thxP}</p></section>
  <section id="gift"><h2 class="sec-h kh foil">${L.giftH}</h2>${orn}<div class="qr-card t-lift" data-in><img src="${qr}" alt="KHQR"></div><div class="btns"><a class="btn kh" href="${qr}" download="khqr-gift.jpg">${L.saveQr}</a></div></section>
  <section id="wishes"><h2 class="sec-h kh foil">${L.wishH}</h2>${orn}<form class="wish" novalidate><p class="kh sub">${L.wishAsk}</p>
  <div class="chips"><label><input type="radio" name="att" value="yes" checked><span class="kh">✓ ${L.yes}</span></label><label><input type="radio" name="att" value="no"><span class="kh">✗ ${L.no}</span></label></div>
  <input name="who" class="kh" placeholder="${L.who}" autocomplete="name"><textarea name="msg" class="kh" rows="4" placeholder="${L.msg}"></textarea>
  <button class="btn kh" type="submit">${L.send}</button><p class="fstat kh" role="status"></p></form></section>
  <footer data-in><h2 class="sec-h kh foil">${L.thanks}</h2>${LOGO()}
  <div class="share">${[['tg', 'tg'], ['ms', 'ms'], ['fb', 'fb'], ['cp', 'cp']].map(([k, t]) => `<button data-share="${k}" class="kh">${P(IC[k])}<span>${L[t]}</span></button>`).join('')}</div>
  <p class="credit">Design inspired by <a href="https://somethphay.me" target="_blank" rel="noopener">Someth Phay · somethphay.me</a></p></footer>`; };

let io;
function bind() { io?.disconnect();
  io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); e.target.querySelector?.('.logo')?.classList.add('play'); io.unobserve(e.target); } }), { threshold: .12 });
  $$('#sx [data-in]').forEach(e => io.observe(e)); onScroll(); }
function onScroll() { const vh = innerHeight;
  $$('.prog').forEach(p => { const r = p.getBoundingClientRect(); p.style.setProperty('--p', Math.max(0, Math.min(1, (vh * .7 - r.top) / r.height)).toFixed(3)); $$('.row', p).forEach(w => w.classList.toggle('on', w.getBoundingClientRect().top < vh * .7)); });
  let cur = 'home'; SEC.forEach(([k, s]) => { const e = $(s); if (e && e.getBoundingClientRect().top < vh * .5) cur = k; });
  $$('.nav button').forEach(b => b.classList.toggle('on', b.dataset.k === cur)); $('.totop')?.classList.toggle('show', scrollY > vh * .6); }
const TARGET = new Date(W.countdown);
function tick() { const s = Math.max(0, Math.floor((TARGET - Date.now()) / 1000)), v = { d: Math.floor(s / 86400), h: Math.floor(s % 86400 / 3600), m: Math.floor(s % 3600 / 60), s: s % 60 };
  $$('[data-cd]').forEach(e => { const t = n(v[e.dataset.cd], lang); if (e.textContent !== t) e.textContent = t; }); }
const stamp = d => d.toISOString().replace(/[-:]|\.\d{3}/g, '');
function ics() { const nm = I.en.names, base = `LOCATION:${I.en.venue.replace(/,/g, '\\,')}\r\nURL:${W.venue.maps}\r\n`;
  const t = `BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//wedding-invite//EN\r\nBEGIN:VEVENT\r\nUID:day1@wedding-invite\r\nDTSTAMP:${stamp(new Date())}\r\nDTSTART;VALUE=DATE:20261120\r\nSUMMARY:Wedding ceremonies (day 1) - ${nm}\r\n${base}END:VEVENT\r\nBEGIN:VEVENT\r\nUID:day2@wedding-invite\r\nDTSTAMP:${stamp(new Date())}\r\nDTSTART:${stamp(TARGET)}\r\nDURATION:PT3H\r\nSUMMARY:Wedding reception - ${nm}\r\n${base}END:VEVENT\r\nEND:VCALENDAR`;
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([t], { type: 'text/calendar' })); a.download = 'wedding.ics'; a.click(); }
function viewer(i) { let v = $('.vw');
  if (!v) { v = document.createElement('div'); v.className = 'vw'; v.innerHTML = `<div class="vs">${G.map(g => `<div class="sl"><img src="${g.lg}" alt=""></div>`).join('')}</div><button class="vx" aria-label="Close">×</button><span class="vc"></span>`; document.body.append(v);
    const s = $('.vs', v), shut = () => { v.classList.remove('open'); document.body.style.overflow = ''; };
    s.onscroll = () => { $('.vc', v).textContent = `${Math.round(s.scrollLeft / s.clientWidth) + 1} / ${G.length}`; };
    v.onclick = e => { if (e.target.closest('.vx') || e.target.classList.contains('sl')) shut(); }; addEventListener('keydown', e => { if (e.key === 'Escape') shut(); }); }
  v.classList.add('open'); document.body.style.overflow = 'hidden'; const s = $('.vs', v); s.scrollTo({ left: i * s.clientWidth, behavior: 'instant' }); s.onscroll(); }
function share(k) { const u = encodeURIComponent(location.href.split('?')[0]), t = encodeURIComponent(I[lang].names);
  if (k === 'cp') { navigator.clipboard?.writeText(location.href).then(() => { const s = $('[data-share=cp] span'); s.textContent = I[lang].copied; }); return; }
  open({ tg: `https://t.me/share/url?url=${u}&text=${t}`, ms: `fb-messenger://share/?link=${u}`, fb: `https://www.facebook.com/sharer/sharer.php?u=${u}` }[k], '_blank'); }

export function mount({ logo }) { LOGO = logo; const root = $('#sx');
  root.addEventListener('click', e => { const g = e.target.closest('[data-g]'), s = e.target.closest('[data-share]');
    if (g) viewer(+g.dataset.g); else if (s) share(s.dataset.share); else if (e.target.closest('[data-ics]')) ics(); });
  document.addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (b) $(b.dataset.go)?.scrollIntoView({ behavior: 'smooth' }); });
  root.addEventListener('submit', async e => { e.preventDefault(); const f = e.target, st = $('.fstat', f), L = I[lang];
    if (!W.wishesEndpoint) { st.textContent = L.wishOff; return; }
    try { const d = new FormData(f); await fetch(W.wishesEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ attend: d.get('att'), name: d.get('who'), message: d.get('msg') }) }); st.textContent = L.wishOk; f.reset(); } catch { st.textContent = L.wishErr; } });
  addEventListener('scroll', onScroll, { passive: true }); addEventListener('resize', onScroll); setInterval(tick, 1000);
  return l => { lang = l; root.innerHTML = html(l); bind(); tick(); }; }
