import { W } from './data/wedding.js';
export const kn = s => String(s).replace(/\d/g, d => '០១២៣៤៥៦៧៨៩'[d]);
const D = W.date;
export const I = {
  km: {
    gateA: 'សិរីសួស្តីអាពាហ៍ពិពាហ៍', gateB: 'The Wedding Invitation', tap: 'ចុចដើម្បីបើកធៀប',
    kicker: 'សិរីសួស្តីអាពាហ៍ពិពាហ៍', invite: 'សូមគោរពអញ្ជើញ',
    lDay: 'ថ្ងៃ', vDay: D.weekdayKm, lDate: 'ទី', vDate: kn(D.d), lMon: 'ខែ', vMon: D.monthKm, lYear: 'ឆ្នាំ', vYear: kn(D.y),
    venue: W.venue.km, scroll: 'អូសចុះក្រោម', other: 'EN',
    names: `${W.groom.en} & ${W.bride.en}`
  },
  en: {
    gateA: 'សិរីសួស្តីអាពាហ៍ពិពាហ៍', gateB: 'The Wedding Invitation', tap: 'Tap to open',
    kicker: 'សិរីសួស្តីអាពាហ៍ពិពាហ៍', invite: 'Together with their families, invite you',
    lDay: 'Day', vDay: D.weekdayEn, lDate: 'Date', vDate: D.d, lMon: 'Month', vMon: D.monthEn, lYear: 'Year', vYear: D.y,
    venue: W.venue.en, scroll: 'Scroll', other: 'ខ្មែរ',
    names: `${W.groom.en} & ${W.bride.en}`
  }
};

Object.assign(I.km, {
  cdH: 'ចំនួនថ្ងៃរាប់ថយក្រោយ', cdLine: 'ថ្ងៃសៅរ៍ ទី២១ ខែវិច្ឆិកា ឆ្នាំ២០២៦ វេលាម៉ោង ៥:០០ ល្ងាច', cd: ['ថ្ងៃ', 'ម៉ោង', 'នាទី', 'វិនាទី'], cal: 'រក្សាទុកក្នុងប្រតិទិន',
  progH: 'របៀបវារៈកម្មវិធី', venueH: 'ទីតាំងកម្មវិធី', mapBtn: 'បើកក្នុង Google Map', galH: 'កម្រងរូបភាព',
  thxH: 'សូមអរគុណ និងសូមអភ័យទោស',
  thxP: 'យើងខ្ញុំទាំងពីរ សូមថ្លែងអំណរគុណយ៉ាងជ្រាលជ្រៅ ចំពោះវត្តមានដ៏ឧត្តុង្គឧត្តមរបស់ សម្តេច ឯកឧត្តម លោកជំទាវ លោកអ្នកឧកញ៉ា អ្នកឧកញ៉ា ឧកញ៉ា លោក លោកស្រី អ្នកនាង កញ្ញា ដែលបានអញ្ជើញចូលរួមជាកិត្តិយស ក្នុងពិធីសិរីសួស្តីអាពាហ៍ពិពាហ៍ របស់យើងខ្ញុំ នាពេលខាងមុខនេះ។ យើងខ្ញុំសូមការខន្តីអភ័យទោស ដែលពុំបានជូនលិខិតអញ្ជើញដោយផ្ទាល់។',
  giftH: 'ចំណងដៃតាមរយៈ KHQR', saveQr: 'រក្សាទុក QR', wishH: 'សារជូនពរ', wishAsk: 'បញ្ជាក់ពីវត្តមានអ្នក', yes: 'ចូលរួម', no: 'បដិសេធ',
  who: 'ឈ្មោះរបស់អ្នក', msg: 'សរសេរសារជូនពរ…', send: 'ផ្ញើ', wishOff: 'មិនទាន់បើកទទួលសារជូនពរ', wishOk: 'អរគុណសម្រាប់សារជូនពរ', wishErr: 'ផ្ញើមិនបាន សូមសាកល្បងម្តងទៀត',
  thanks: 'សូមអរគុណ', tg: 'ផ្ញើតាម Telegram', ms: 'ផ្ញើតាម Messenger', fb: 'ផ្ញើតាម Facebook', cp: 'ចម្លងតំណភ្ជាប់', copied: 'បានចម្លង'
});
Object.assign(I.en, {
  cdH: 'Countdown', cdLine: 'Saturday, 21 November 2026 · 5:00 PM', cd: ['Days', 'Hours', 'Minutes', 'Seconds'], cal: 'Save to calendar',
  progH: 'Programme', venueH: 'Venue', mapBtn: 'Open in Google Maps', galH: 'Gallery',
  thxH: 'Thank you, and our apologies',
  thxP: 'We both offer our deepest thanks for the honoured presence of every guest who will join our wedding celebration. We sincerely apologise that we could not deliver each invitation in person.',
  giftH: 'Wedding gift via KHQR', saveQr: 'Save QR', wishH: 'Wishes', wishAsk: 'Will you attend?', yes: 'Attending', no: 'Can’t make it',
  who: 'Your name', msg: 'Write your wishes…', send: 'Send', wishOff: 'Wishes are not open yet', wishOk: 'Thank you for your wishes', wishErr: 'Could not send. Please try again.',
  thanks: 'Thank you', tg: 'Send via Telegram', ms: 'Send via Messenger', fb: 'Send via Facebook', cp: 'Copy link', copied: 'Copied'
});
