// Bundles the site into ONE self-contained html file (assets inlined) for quick previews.
const esbuild=require('esbuild'),fs=require('fs');
esbuild.buildSync({entryPoints:['src/main.js'],bundle:true,minify:true,format:'iife',outdir:'.preview',
  loader:{'.webp':'dataurl','.mp3':'dataurl','.png':'dataurl'},logLevel:'error'});
const js=fs.readFileSync('.preview/main.js','utf8').replace(/<\/script/g,'<\\/script'), css=fs.readFileSync('.preview/main.css','utf8');
let html=fs.readFileSync('index.html','utf8').replace('%VITE_SITE_URL%','').replace(/<script type="module"[^>]*><\/script>/,'');
html=html.replace('</head>',()=>`<style>${css}</style></head>`).replace('</body>',()=>`<script>${js}</script></body>`);
fs.mkdirSync('dist-preview',{recursive:true});fs.writeFileSync('dist-preview/index.html',html);
console.log('preview',(html.length/1e6).toFixed(2)+' MB');
