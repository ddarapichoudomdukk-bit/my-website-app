const { chromium } = require('playwright'); const fs=require('fs');
(async()=>{ const b=await chromium.launch(); const out=[];
 for(const [w,h] of [[390,844],[320,568],[1280,800]]){
  const p=await (await b.newContext({viewport:{width:w,height:h},hasTouch:w<800})).newPage(); const errs=[];
  p.on('console',m=>m.type()==='error'&&errs.push(m.text().slice(0,70))); p.on('pageerror',e=>errs.push(String(e).slice(0,90)));
  await p.goto('file://'+process.cwd()+'/dist-preview/index.html?qa'); await p.waitForTimeout(500);
  await p.evaluate(()=>{__qa.open();__qa.reveal()}); await p.waitForTimeout(1500);
  const H=await p.evaluate(()=>document.documentElement.scrollHeight);
  for(let y=0;y<H;y+=h*.6){await p.evaluate(y=>scrollTo({top:y,behavior:'instant'}),y);await p.waitForTimeout(120)}
  await p.waitForTimeout(1500);
  if(w===390){ await p.evaluate(()=>scrollTo({top:0,behavior:'instant'})); await p.waitForTimeout(300);
    const n=Math.ceil(H/h); for(let i=0;i<n;i++){await p.evaluate(y=>scrollTo({top:y,behavior:'instant'}),i*h);await p.waitForTimeout(900);await p.screenshot({path:`qa/s390-${String(i).padStart(2,'0')}.png`})}
    await p.evaluate(()=>document.querySelector('[data-g="1"]').click()); await p.waitForTimeout(500); await p.screenshot({path:'qa/viewer.png'}); await p.keyboard.press('Escape');
    await p.evaluate(()=>{document.querySelector('.wish [type=submit]').click()}); await p.waitForTimeout(200);
    out.push({wishMsg:await p.evaluate(()=>document.querySelector('.fstat').textContent)}); }
  const m=await p.evaluate(()=>{const W=innerWidth,bad=[];document.querySelectorAll('body *').forEach(e=>{const r=e.getBoundingClientRect();if(r.width&&(r.right>W+1||r.left<-1)&&!e.closest('.gate,.cover-bg,.corner,.vw,.vs,.sl'))bad.push((e.className&&e.className.baseVal!==undefined?e.className.baseVal:e.className)||e.tagName)});
   return{sw:document.documentElement.scrollWidth,W,bad:[...new Set(bad)].slice(0,8),cd:[...document.querySelectorAll('[data-cd]')].map(e=>e.textContent).join(','),rows:document.querySelectorAll('.row').length,figs:document.querySelectorAll('.masonry figure.in').length}});
  out.push({vp:w+'x'+h,H,errs:[...new Set(errs)],...m}); await p.close(); }
 console.log(JSON.stringify(out,null,1)); await b.close(); })();
