// Run: npm run assets   (needs sharp + ffmpeg). Photos, tinted textures, SVG sprite, QR crop, audio.
const sharp = require("sharp"),
  fs = require("fs"),
  cp = require("child_process");
const A = "src/assets/",
  K = "kit/elements/";
const SILVER = ["#8a8f96", "#d9dde2", "#ffffff"],
  GOLD = ["#9c7124", "#d9b15a", "#fbefc0"];
(async () => {
  // photos: sharp drops EXIF/GPS by default; 640/1280/2000 webp
  const hero = sharp(A + "hero-src.jpg").rotate();
  for (const w of [640, 1280, 2000])
    await hero
      .clone()
      .resize(w)
      .webp({ quality: w > 1000 ? 78 : 70 })
      .toFile(`${A}couple-${w}.webp`);
  await hero
    .clone()
    .extract({ left: 0, top: 120, width: 1365, height: 717 })
    .resize(1200, 630)
    .jpeg({ quality: 82 })
    .toFile("public/og.jpg");
  // gallery: ./photos/* -> src/assets/g/<id>-{640,1280}.webp + src/gallery.js (order = ORDER, then the rest)
  fs.mkdirSync("src/assets/g", { recursive: true });
  const gallery = [];
  const ORDER = [
    "121a1406",
    "121a1902",
    "121a1179",
    "121a2193",
    "121a1541",
    "121a1299",
    "121a1636",
    "121a1629",
  ];
  const files = fs
    .readdirSync("photos")
    .filter((f) => /\.(jpe?g|png|webp)$/i.test(f))
    .sort((x, y) => {
      const i = ORDER.indexOf(x.split(".")[0].toLowerCase()),
        j = ORDER.indexOf(y.split(".")[0].toLowerCase());
      return (i < 0 ? 99 : i) - (j < 0 ? 99 : j);
    });
  for (const f of files) {
    const id = f.replace(/\.[^.]+$/, "").toLowerCase(),
      img = sharp("photos/" + f).rotate(),
      m = await img.clone().metadata();
    const [w, h] =
      m.orientation >= 5 ? [m.height, m.width] : [m.width, m.height];
    for (const sz of [640, 1280])
      await img
        .clone()
        .resize({ width: Math.min(sz, w) })
        .webp({ quality: sz > 1000 ? 76 : 70 })
        .toFile(`src/assets/g/${id}-${sz}.webp`);
    gallery.push({ id, w, h });
  }
  fs.writeFileSync(
    "src/gallery.js",
    gallery
      .map(
        (g, i) =>
          `import s${i} from './assets/g/${g.id}-640.webp';import l${i} from './assets/g/${g.id}-1280.webp';`,
      )
      .join("\n") +
      `\nexport default [${gallery.map((g, i) => `{id:'${g.id}',w:${g.w},h:${g.h},sm:s${i},lg:l${i}}`).join(",")}];`,
  );
  // textures tinted to the card palette (keeps the kit's grain)
  const tint = async (src, dst, [r, g, b], gain) => {
    const { data, info } = await sharp(`kit/textures/${src}.webp`)
      .removeAlpha()
      .raw()
      .toBuffer({ resolveWithObject: true });
    let m = 0;
    for (let i = 0; i < data.length; i += 3)
      m += (data[i] + data[i + 1] + data[i + 2]) / 3;
    m /= data.length / 3;
    const out = Buffer.alloc(data.length);
    for (let i = 0; i < data.length; i += 3) {
      const k = 1 + ((data[i] + data[i + 1] + data[i + 2]) / 3 / m - 1) * gain;
      out[i] = Math.min(255, r * k);
      out[i + 1] = Math.min(255, g * k);
      out[i + 2] = Math.min(255, b * k);
    }
    await sharp(out, { raw: info })
      .webp({ quality: 80 })
      .toFile(A + dst);
  };
  await tint("paper-olive", "paper-navy.webp", [35, 53, 84], 1.6);
  await tint("paper-cream", "paper-cream.webp", [243, 241, 236], 1);
  await tint("paper-lining", "paper-lining.webp", [232, 228, 220], 1);
  // KHQR: crop the card only (drops status bar and account numbers)
  await sharp(A + "qr-src.png")
    .extract({ left: 88, top: 256, width: 414, height: 608 })
    .jpeg({ quality: 92 })
    .toFile(A + "qr-aba.jpg");
  cp.execSync(
    `ffmpeg -y -loglevel error -i ${A}music-src.mp3 -b:a 64k ${A}music.mp3`,
  );
  // sprite: kit elements, metadata stripped, silver foil (seal keeps gold)
  const foil = (c, id) =>
    `<linearGradient id="${id}" x1="0" y1="0" x2="1" y2=".35"><stop offset="0" stop-color="${c[0]}"/><stop offset=".25" stop-color="${c[1]}"/><stop offset=".45" stop-color="${c[2]}"/><stop offset=".62" stop-color="${c[1]}"/><stop offset=".85" stop-color="${c[0]}"/><stop offset="1" stop-color="${c[1]}"/></linearGradient>`;
  let sym = "";
  for (const f of fs.readdirSync(K)) {
    let s = fs
      .readFileSync(K + f, "utf8")
      .replace(/<metadata>[\s\S]*?<\/metadata>/g, "")
      .replace(/<\?xml.*?\?>/g, "");
    const vb = s.match(/viewBox="([^"]+)"/)[1];
    let inner = s
      .replace(/^[\s\S]*?<svg[^>]*>/, "")
      .replace(/<\/svg>\s*$/, "")
      .replace(/<linearGradient id="g-foil"[\s\S]*?<\/linearGradient>/, "");
    inner = inner.replace(/<style[\s\S]*?<\/style>/g, "");
    if (f === "wax-seal.svg")
      inner = inner
        .replace(/#g-foil/g, "#g-gold")
        .replace(/kb-(fill|line)/g, "kg-$1");
    sym += `<symbol id="el-${f.replace(".svg", "")}" viewBox="${vb}">${inner}</symbol>`;
  }
  sym +=
    '<symbol id="heart" viewBox="0 0 24 22"><path d="M12 21C5 15 1 11.5 1 7.2 1 4 3.4 2 6 2c2.4 0 4.6 1.4 6 3.7C13.4 3.4 15.6 2 18 2c2.600 0 5 2 5 5.200C23 11.500 19 15 12 21z" fill="url(#g-gold)"/></symbol>';
  fs.writeFileSync(
    "src/sprite.js",
    "export default " +
      JSON.stringify(
        `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>${foil(SILVER, "g-foil")}${foil(GOLD, "g-gold")}<style>.kb-fill{fill:url(#g-foil)}.kb-line{fill:none;stroke:url(#g-foil);stroke-width:1.6;stroke-linecap:round}.kg-fill{fill:url(#g-gold)}.kg-line{fill:none;stroke:#d9b15a;stroke-width:1.6;stroke-linecap:round}</style></defs>${sym}</svg>`,
      ) +
      ";",
  );
  console.log("assets ok");
})();
