const { chromium } = require('playwright');
const VP=[[390,844],[320,568],[740,360],[1280,800]];
const FR=[0,700,1500,2300,3000,3900,4800,5400];
(async()=>{
  const b=await chromium.launch(); const rep=[];
  for(const [w,h] of VP){
    const p=await (await b.newContext({viewport:{width:w,height:h},deviceScaleFactor:1,hasTouch:w<800})).newPage();
    const errs=[]; p.on('console',m=>m.type()==='error'&&errs.push(m.text())); p.on('pageerror',e=>errs.push(String(e)));
    await p.goto('file://'+process.cwd()+'/dist-preview/index.html?qa'); await p.waitForTimeout(600);
    if(w===390||w===1280){ await p.screenshot({path:`qa/${w}-gate.png`}); }
    await p.evaluate(()=>window.__qa.open());
    if(w===390) for(const t of FR){ await p.evaluate(t=>window.__qa.seek(t),t); await p.waitForTimeout(80); await p.screenshot({path:`qa/390-f${String(t).padStart(4,'0')}.png`}); }
    await p.evaluate(()=>window.__qa.reveal()); await p.waitForTimeout(4200);
    await p.screenshot({path:`qa/${w}x${h}-cover.png`});
    const m=await p.evaluate(()=>{const W=innerWidth,bad=[];document.querySelectorAll('body *').forEach(e=>{const r=e.getBoundingClientRect();if(r.width&&(r.right>W+1||r.left<-1)&&!e.closest('.gate-bg,.cover-bg,.corner'))bad.push(e.className||e.tagName)});
      const c=document.querySelector('.cover-in').getBoundingClientRect(),cv=document.querySelector('.cover').getBoundingClientRect();
      return{sw:document.documentElement.scrollWidth,W,bad:[...new Set(bad)].slice(0,6),coverH:Math.round(cv.height),innerH:innerHeight,contentH:Math.round(c.height)}});
    rep.push({vp:`${w}x${h}`,errs,...m});
    await p.close();
  }
  console.log(JSON.stringify(rep,null,1)); await b.close();
})();
